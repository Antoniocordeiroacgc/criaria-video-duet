
import { useState, useRef, useCallback, useEffect } from 'react';

export function useMediaRecorder() {
  const [stream, setStream] = useState(null);
  const [recordingState, setRecordingState] = useState('idle');
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [error, setError] = useState(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const startTimeRef = useRef(null);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (recordingState === 'recording') {
      stopRecording();
    }
  }, [stream, recordingState]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [stopCamera]);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: true
      });
      setStream(mediaStream);
      setRecordedBlob(null); // Reset any previous recording when starting camera
      return mediaStream;
    } catch (err) {
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('Acesso à câmera e microfone negado. Por favor, permita as permissões.');
      } else if (err.name === 'NotFoundError') {
        setError('Nenhuma câmera ou microfone encontrado. Verifique seu dispositivo.');
      } else {
        setError('Falha ao acessar câmera e microfone. Verifique suas configurações.');
      }
      return null;
    }
  }, []);

  const startRecording = useCallback(() => {
    try {
      if (!stream) {
        setError('A câmera precisa estar ligada para gravar.');
        return;
      }

      chunksRef.current = [];
      setRecordedBlob(null);
      setError(null);

      const options = { mimeType: 'video/webm;codecs=vp9,opus' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) {
        options.mimeType = 'video/webm';
        if (!MediaRecorder.isTypeSupported(options.mimeType)) {
          options.mimeType = 'video/mp4';
        }
      }

      const recorder = new MediaRecorder(stream, options);
      
      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType });
        setRecordedBlob(blob);
        setRecordingState('stopped');
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };

      recorder.onerror = () => {
        setError('A gravação falhou. Tente novamente.');
        setRecordingState('idle');
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start(100);
      setRecordingState('recording');
      
      startTimeRef.current = Date.now();
      setRecordingDuration(0);
      timerRef.current = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setRecordingDuration(elapsed);
      }, 100);

    } catch (err) {
      setError('Falha ao iniciar gravação. Tente novamente.');
      setRecordingState('idle');
    }
  }, [stream]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && recordingState === 'recording') {
      mediaRecorderRef.current.stop();
    }
  }, [recordingState]);

  const resetRecording = useCallback(() => {
    setRecordedBlob(null);
    setRecordingState('idle');
    setRecordingDuration(0);
    chunksRef.current = [];
  }, []);

  return {
    stream,
    recordingState,
    recordedBlob,
    error,
    recordingDuration,
    startCamera,
    stopCamera,
    startRecording,
    stopRecording,
    resetRecording
  };
}
