
import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';

const VideoPlayer = forwardRef(({ src, className = '' }, ref) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={`relative w-full ${className}`}
      style={{ aspectRatio: '16/9' }}
    >
      <video
        ref={ref}
        src={src}
        controls
        playsInline
        className="w-full h-full object-cover rounded-xl bg-black border border-border/50 shadow-lg"
      >
        Seu navegador não suporta a reprodução de vídeo.
      </video>
    </motion.div>
  );
});

VideoPlayer.displayName = 'VideoPlayer';

export default VideoPlayer;
