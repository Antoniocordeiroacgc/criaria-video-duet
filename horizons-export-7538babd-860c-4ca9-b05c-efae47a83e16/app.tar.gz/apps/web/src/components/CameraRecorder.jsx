
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Video, Square, Circle, Camera, CameraOff, Download, UploadCloud, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMediaRecorder } from '@/hooks/useMediaRecorder.js';

export default function CameraRecorder({ onRecordingComplete }) {
  const videoRef = useRef(null);
  const {
    stream,
    recordingState,
    recordedBlob,
    error,
    recordingDuration,
    startCamera,
    stopCamera,
    startRecording,
    stopRecording,
    resetRecording
  } = useMediaRecorder();

  const [uploadStatus, setUploadStatus] = useState('idle');

  // Bind the camera stream to the video element
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  useEffect(() => {
    if (recordedBlob && onRecordingComplete) {
      onRecordingComplete(recordedBlob);
    }
  }, [recordedBlob, onRecordingComplete]);

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDownload = () => {
    if (recordedBlob) {
      const url = URL.createObjectURL(recordedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `gravacao-${Date.now()}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 100);
    }
  };

  const handleSimulateUpload = () => {
    setUploadStatus('uploading');
    // Simulate network delay
    setTimeout(() => {
      setUploadStatus('success');
    }, 2000);
  };

  const handleNewRecording = () => {
    setUploadStatus('idle');
    resetRecording();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full flex flex-col gap-4"
    >
      <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-border/50 shadow-lg">
        {stream ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/50">
            <Video className="w-16 h-16 text-muted-foreground mb-3" />
            <p className="text-muted-foreground text-sm">A câmera está desligada</p>
          </div>
        )}
        
        {recordingState === 'recording' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute top-4 left-4 flex items-center gap-2 bg-destructive/90 text-white px-3 py-1.5 rounded-lg shadow-sm"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <Circle className="w-3 h-3 fill-current" />
            </motion.div>
            <span className="text-sm font-medium">REC</span>
          </motion.div>
        )}

        {recordingState === 'recording' && (
          <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1.5 rounded-lg backdrop-blur-sm">
            <span className="text-sm font-medium font-variant-numeric tabular-nums">
              {formatDuration(recordingDuration)}
            </span>
          </div>
        )}
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg"
        >
          <p className="text-sm text-destructive">{error}</p>
        </motion.div>
      )}

      {/* Control Actions */}
      <div className="flex flex-col gap-4">
        {/* State 1: No recorded blob yet */}
        {!recordedBlob && (
          <div className="flex flex-wrap items-center justify-center gap-3">
            {!stream ? (
              <Button
                onClick={startCamera}
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              >
                <Camera className="w-5 h-5 mr-2" />
                Ligar Câmera
              </Button>
            ) : (
              <>
                <Button
                  onClick={stopCamera}
                  size="lg"
                  variant="secondary"
                  className="font-medium"
                  disabled={recordingState === 'recording'}
                >
                  <CameraOff className="w-5 h-5 mr-2" />
                  Desligar Câmera
                </Button>

                {recordingState === 'idle' ? (
                  <Button
                    onClick={startRecording}
                    size="lg"
                    className="bg-destructive hover:bg-destructive/90 text-destructive-foreground font-medium"
                  >
                    <Circle className="w-5 h-5 mr-2 fill-current" />
                    Gravar
                  </Button>
                ) : (
                  <Button
                    onClick={stopRecording}
                    size="lg"
                    className="bg-destructive hover:bg-destructive/90 text-destructive-foreground font-medium"
                  >
                    <Square className="w-5 h-5 mr-2 fill-current" />
                    Parar Gravação
                  </Button>
                )}
              </>
            )}
          </div>
        )}

        {/* State 2: Blob generated after stopping recording */}
        {recordedBlob && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col gap-3 p-4 bg-card border border-border rounded-xl"
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-foreground">Gravação concluída</h3>
              <span className="text-xs text-muted-foreground">
                {(recordedBlob.size / (1024 * 1024)).toFixed(2)} MB
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                onClick={handleDownload}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Download className="w-4 h-4 mr-2" />
                Baixar Vídeo
              </Button>
              
              <Button
                onClick={handleSimulateUpload}
                variant="secondary"
                className="w-full"
                disabled={uploadStatus !== 'idle'}
              >
                {uploadStatus === 'idle' && <><UploadCloud className="w-4 h-4 mr-2" /> Simular Upload</>}
                {uploadStatus === 'uploading' && <><span className="w-4 h-4 mr-2 border-2 border-current border-t-transparent rounded-full animate-spin" /> Enviando...</>}
                {uploadStatus === 'success' && <><CheckCircle2 className="w-4 h-4 mr-2 text-green-500" /> Upload Concluído</>}
              </Button>
            </div>

            <Button
              onClick={handleNewRecording}
              variant="ghost"
              className="mt-2 text-muted-foreground hover:text-foreground"
            >
              Fazer nova gravação
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
